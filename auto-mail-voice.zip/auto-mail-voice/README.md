# Automatic Mail Sender with Voice Detection

**Simple Python project** that listens for a voice trigger (e.g. "send email") and then records recipient, subject and body by voice and sends an email using SMTP.

> ⚠️ This is a starter project. You must provide your SMTP credentials (use app passwords for Gmail). For production use, secure credentials (env vars, secret manager) must be used.

## Features
- Voice trigger (hotword) using `speech_recognition`.
- Voice-to-text for recipient, subject and body.
- Sends email via SMTP (SSL).

## Quick start

1. Clone or download this repository and create a virtual environment:

```bash
python -m venv venv
source venv/bin/activate    # macOS / Linux
# venv\Scripts\activate   # Windows
pip install -r requirements.txt
```

2. Copy `config.example.json` to `config.json` and fill your SMTP settings:

```json
{
  "smtp_host": "smtp.gmail.com",
  "smtp_port": 465,
  "username": "your-email@gmail.com",
  "password": "your-app-password"
}
```

3. Run:

```bash
python src/main.py
```

Say **"send email"** (or **"send mail"**) when the app is listening. Then follow voice prompts:
- "Recipient email"
- "Subject"
- "Body"
- You will be asked to confirm by speaking "yes" (optional).

## Notes & troubleshooting
- `pyaudio` may be tricky to install on some platforms. On Windows, try `pip install pipwin` then `pipwin install pyaudio`.
- For Gmail, enable 2FA and create an *app password* to use as `password` in `config.json`.
- This project uses blocking microphone listen loops — adapt for continuous background detection if desired.

## License
MIT
